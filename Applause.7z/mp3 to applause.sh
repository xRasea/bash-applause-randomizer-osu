#!/bin/sh

for file in ./notrandom/*.mp3; do
    cp -f -- "$file" "applause$RANDOM-$RANDOM.mp3"
done
mv $(ls -1 | head -n 1) applause.mp3

